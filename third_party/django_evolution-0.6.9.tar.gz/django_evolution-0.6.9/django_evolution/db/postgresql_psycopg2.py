# Psycopg2 behaviour is identical to Psycopg1
from postgresql import *